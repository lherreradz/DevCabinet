export const handler =async (event:any) => {
    
    console.log(event)

    return{
        status:200,
        body: JSON.stringify({message: 'Hello world'})
    }
}

// serverless config credentials --provider aws --key AKIATYLNGKNOYDVNAUOY --secret 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